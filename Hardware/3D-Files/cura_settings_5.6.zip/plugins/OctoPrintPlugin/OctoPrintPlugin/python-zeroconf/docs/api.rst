python-zeroconf API reference
=============================

.. automodule:: zeroconf
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: zeroconf.asyncio
    :members:
    :undoc-members:
    :show-inheritance:
